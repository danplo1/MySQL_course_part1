<?php
	$host="localhost"; // Nazwa hosta
	$user="root"; // Nazwa uzytkownika mysql
	$password=""; // Haslo do bazy
	$database="samochody"; // Nazwa bazy
?>